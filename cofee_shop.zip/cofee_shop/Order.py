from Menu import menu
orders = []

def add_order():
    food_name = input("Enter product name: ") 
    if food_name in menu:
        qty = int(input("Enter quantity: "))
        
        price = menu[food_name]
        
        new_order = {"name": food_name, "price": price, "qty": qty}
        orders.append(new_order)
        print("Order added!")
    else:
        print("Error: This product is not in the menu.")

def show_orders():
    if len(orders) == 0:
        print("No orders yet.")
    else:
        print("\n--- Your Orders ---")
        for item in orders:
            print("Name:", item["name"], "| Price:", item["price"], "| Qty:", item["qty"])
        print("-------------------")