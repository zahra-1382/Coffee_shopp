from Order import orders

def calculate_total():
    total = 0
    for item in orders:
        
        total = total + (item["price"] * item["qty"])
    return total

def calculate_discount(total_price):
   
    if total_price > 1000000:
        discount = total_price * 0.10
    else:
        discount = 0
    return discount

def print_invoice():
    if len(orders) == 0:
        print("No orders to print.")
        return

    print("\n========== INVOICE ==========")
    for item in orders:
        print(item["name"], "x", item["qty"], "=", item["price"] * item["qty"])
    
    total = calculate_total()
    discount = calculate_discount(total)
    final_pay = total - discount
    
    print("-----------------------------")
    print("Total:", total)
    print("Discount:", discount)
    print("Final Payment:", final_pay)
    print("=============================")