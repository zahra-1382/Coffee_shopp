menu = {
    "coffee": 80000,
    "tea": 50000,
    "cake": 120000
}

def show_menu():
    print("\n--- Menu ---")
    for item in menu:
        print(item, ":", menu[item], "Toman")
    print("------------")